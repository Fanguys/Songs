SELECT name from songs;
